const studentForm = document.forms["student-form"]

const studentData = document
    .getElementById('student-data')
    .getElementsByTagName('tbody')[0]


function submitData() {
    const student = {
        name: studentForm['first_name'].value,
        gender: studentForm['gender'].value,
        course: studentForm['program'].value
    }

    const newRow = studentData.insertRow(0)

    for(let field in student) {
        const newCell = newRow.insertCell()

        newCell.setAttribute('class', 'px-6 py-4')

        newCell.innerHTML = student[field]
    }

    studentForm.reset()
}
